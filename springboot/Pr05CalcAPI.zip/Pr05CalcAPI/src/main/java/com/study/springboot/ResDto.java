package com.study.springboot;

import lombok.Data;

@Data
public class ResDto {
    private int result;
}
